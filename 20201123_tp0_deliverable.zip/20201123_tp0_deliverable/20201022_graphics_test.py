from cmu_112_graphics import *

def appStarted(app):
    app.points = 20
    app.myX = 20
    app.myY = 20
    app.dy = app.dx = 20
    app.size = 10
    app.myColor = 'cyan'
    app.background = rgbString(197,197,197)

def rgbString(r, g, b):
    # Don't worry about the :02x part, but for the curious,
    # it says to use hex (base 16) with two digits.
    return f'#{r:02x}{g:02x}{b:02x}'

def keyPressed(app,event):
    if event.key == 'Up':
        moveCharacter(app,(0,-1))
    elif event.key == 'Down':
        moveCharacter(app,(0,1))
    elif event.key == 'Left':
        moveCharacter(app,(-1,0))
    elif event.key == 'Right':
        moveCharacter(app,(1,0))

def drawCharacter(app,canvas):
    canvas.create_oval(app.myX-app.size,app.myY-app.size,app.myX+app.size,app.myY+app.size,fill=app.myColor,width=0)

def moveCharacter(app,direction):
    xDir,yDir = direction
    app.myX += xDir*app.dx
    app.myY += yDir*app.dy

def redrawAll(app,canvas):
    canvas.create_rectangle(0,0,app.height,app.width, fill=app.background)
    drawCharacter(app,canvas)
    
runApp(height=400,width=400)