# rootDir = '/home/dee/Music'
# testKey = '/Manchester Orchestra/Simple Math/Simple Math.flac'
# statsTracking = dict()
# statsTracking[testKey] = 1

# <playlist title='testPlaylist'>
#     <track>
#         <title>Simple Math</title>
#         <path>/Manchester Orchestra/Simple Math/Simple Math.flac</path>
#     </track>
#     <track>
#         <title>Millennia</title>
#         <path>/home/dee/Music/Crown The Empire/The Resistance Rise Of The Runaways/Millennia.flac</path>
#     </track>
# </playlist>

# testing ElementTree vs BeautifulSoup, decided on ElementTree
# used https://www.geeksforgeeks.org/reading-and-writing-xml-files-in-python/
# as a source for figuring this out

import xml.etree.ElementTree as ET
root = ET.Element('playlists')
playlist = ET.SubElement(root,'playlist')
playlist.set('title','testPlaylist')
track = ET.SubElement(playlist,'track')
title = ET.SubElement(track,'title')
title.text = 'Simple Math'
path = ET.SubElement(track,'path')
path.text = '/home/dee/Music/Manchester Orchestra/Simple Math/Simple Math.flac'
ET.dump(root)

tree = ET.ElementTree(root)
playlist_file = open('test_playlist.xml','wb')
tree.write(playlist_file)