from cmu_112_graphics import *
from pygame import mixer

def appStarted(app):
    app.rootDir = './'
    mixer.init()
    app.paused = True
    app.loaded = False

def mousePressed(app,event):
    if event.x < 100 and event.x > 20 and event.y < 100 and event.y > 20:
        if not app.loaded:
            mixer.music.load("Simple Math.flac")
            mixer.music.set_volume(0.2)
            mixer.music.play()
            app.loaded = not app.loaded
        app.paused = not app.paused

def redrawAll(app,canvas):
    canvas.create_rectangle(20,20,100,100,fill='blue')

def timerFired(app):
    if app.paused:
        mixer.music.pause()
    else:
        mixer.music.unpause()

runApp(width=500,height=500)