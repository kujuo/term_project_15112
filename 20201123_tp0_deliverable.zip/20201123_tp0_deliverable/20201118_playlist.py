# working demo code with creation of a plyalist
# with playlist class and using cmu 112 graphics

# referenced previous code regarding pygame mixer,
# and article: https://www.geeksforgeeks.org/python-playing-audio-file-in-pygame/

class Playlist(object):
    numPlaylists = 0
    def __init__(self,title,parent):
        self.title = title
        self.parent = parent
        self.songs = []

    def addSong(self,song):
        self.songs.append(song)
    
    def incrementPlaylists():
        Playlist.numPlaylists += 1

    def getSongs(self):
        if self.parent != None:
            return self.parent.getSongs() + self.songs
        else:
            return self.songs
    
    def addParent(self,parent):
        self.parent = parent
    

from dataclasses import make_dataclass


# print(p1.getSongs(),p2.getSongs())

from pygame import mixer
from cmu_112_graphics import *

Song = make_dataclass('Song',['title','path'])

# cmu_112_graphics framework taken from previous 112 code with graphics

def appStarted(app):
    mixer.init()
    app.playX1 = app.width//2-20
    app.playY1 = app.height//2+50-20
    app.playX2 = app.width//2+20
    app.playY2 = app.height//2+50+20
    app.buttons = dict()
    app.buttons['play'] = (app.playX1,app.playY1,app.playX2,app.playY2)

    app.paused = False
    app.loaded = False

    s1 = Song(title='Welcome Home',
            path="/home/dee/Music/Coheed and Cambria/Good Apollo I'm Burning Star IV Volume One From Fear Through The Eyes Of Madness/Welcome Home.flac")
    s2 = Song(title='Millennia',path='/home/dee/Music/Crown The Empire/The Resistance Rise Of The Runaways/Millennia.flac')
    s3 = Song(title='Simple Math',path='./music_examples/Simple Math.flac')
    # s4 = Song(title='jfkdsjfldkf',path='/home/dee/Music/Kevin Karla y La Banda/Flashlight.mp3')
    app.p1 = Playlist('test1',None)
    app.p1.addSong(s3)
    app.p2 = Playlist('test2',app.p1)
    app.p2.addSong(s2)
    app.p2.addSong(s1)
    # app.p2.addSong(s4)

    mixer.music.load(app.p2.getSongs()[0].path)
    for song in app.p2.getSongs()[1:]:
        print(song.path)
        mixer.music.queue(song.path)

def mousePressed(app,event):
    if inButton(app,'play',event.x,event.y):
        if app.loaded:
            if app.paused:
                mixer.music.unpause()
            else:
                mixer.music.pause()
            app.paused = not app.paused
        else:
            mixer.music.play()
            app.loaded = not app.loaded
    
def keyPressed(app,event):
    if event.key == 'Right':
        pass
    if event.key == 'Space':
        if app.loaded:
            if app.paused:
                mixer.music.unpause()
            else:
                mixer.music.pause()
            app.paused = not app.paused
        else:
            mixer.music.play()
            app.loaded = not app.loaded
        

def timerFired(app):
    pass

def inButton(app,button,x,y):
    x1,y1,x2,y2 = app.buttons[button]
    print(f'x1: {x1} <= x: {x} <= x2: {x2}')
    print(f'y1: {y1} <= y: {y} <= y2: {y2}')
    return x1 <= x <= x2 and y1 <= y <= y2

def drawHomeScreen(app,canvas):
    # play button
    canvas.create_rectangle(app.playX1,app.playY1,app.playX2,app.playY2,fill='blue')

def drawSongsInPlaylist(app,canvas,playlist):
    for i in range(len(playlist.getSongs())):
        canvas.create_text(100,50+i*10,text=playlist.getSongs()[i].title)

def drawAllSongs(app,canvas):
    pass

def redrawAll(app,canvas):
    drawHomeScreen(app,canvas)
    drawSongsInPlaylist(app,canvas,app.p2)

runApp(width=600,height=600)