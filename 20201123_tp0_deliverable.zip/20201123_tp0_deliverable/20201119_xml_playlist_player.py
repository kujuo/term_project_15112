from cmu_112_graphics import *
import xml.etree.ElementTree as ET
from pygame import mixer
from dataclasses import make_dataclass
# tutorial used for XML file IO: https://www.geeksforgeeks.org/reading-and-writing-xml-files-in-python/
# playlist class
class Playlist(object):
    numPlaylists = 0
    playlist_file = open('test_playlist.xml','wb')
    tree = ET.parse(playlist_file)
    root = tree.getroot()
    def __init__(self,title,parent):
        self.title = title
        self.parent = parent
        self.songs = []
        
    def addSong(self,song):
        self.songs.append(song)
    
    def incrementPlaylists():
        Playlist.numPlaylists += 1

    def getSongs(self):
        if self.parent != None:
            return self.parent.getSongs() + self.songs
        else:
            return self.songs
    
    def addParent(self,parent):
        self.parent = parent

    def savePlaylist(self):
        playlist = ET.SubElement(root,'playlist')
        playlist.set('title',title)
        for song in self.songs:
            track = ET.SubElement(playlist,'track')
            title = ET.SubElement(track,'title')
            title.text = song.title
            path = ET.SubElement(track,'path')
            path.text = song.path
