# sourced/adapted from https://www.dataquest.io/blog/last-fm-api-python/
import requests 

song_data_file = open('test_songdata.xml','wb')


def lastfmGet(payload):    
    API_KEY = '43a1115a43350f02986daf50d4e99a9a'
    USER_AGENT = 'driyer'

    headers = {
        'user-agent': USER_AGENT
    }
    payload['api_key'] = API_KEY
    payload['format'] = 'xml'

    response = requests.get('http://ws.audioscrobbler.com/2.0', headers=headers, params=payload)
    return response

print(lastfmGet({'method':'album.getInfo','artist':'Crown The Empire','album':'Sudden Sky'}).text)